package uz.zikr.bubble

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val p = (24 * d).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(p, p, p, p)
        }
        col.addView(TextView(this).apply {
            text = "Zikr sanagich"
            textSize = 24f
            setTextColor(Color.parseColor("#0E7F68"))
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "Yashil doira barcha ilovalar ustida turadi.\nBosish: +1  ·  Surish: koʻchirish  ·  Uzoq bosish: nolga"
            gravity = Gravity.CENTER
            setPadding(0, p / 2, 0, p)
        })
        col.addView(Button(this).apply {
            text = "Doirani yoqish"
            setOnClickListener { start() }
        })
        col.addView(Button(this).apply {
            text = "Doirani oʻchirish"
            setOnClickListener { stopService(Intent(this@MainActivity, BubbleService::class.java)) }
        })
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, BubbleService::class.java))
    }
}
