package uz.zikr.bubble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var num: TextView
    private var bubble: View? = null
    private var count = 0
    private val target = 33

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(1, notification())
        if (bubble == null) addBubble()
        return START_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("zikr", "Zikr", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, BubbleService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "zikr")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle("Zikr sanagich ishlayapti")
            .addAction(0, "Toʻxtatish", stop)
            .build()
    }

    private fun addBubble() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("zikr", MODE_PRIVATE)
        count = prefs.getInt("count", 0)
        val d = resources.displayMetrics.density
        val size = (84 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1DB881.toInt(), 0xFF0E7F68.toInt())
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke((3 * d).toInt(), 0xFF4CD0A0.toInt())
            }
        }
        num = TextView(this).apply {
            text = count.toString()
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val label = TextView(this).apply {
            text = "ZIKR"
            setTextColor(0xFFCFF5E6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
        }
        root.addView(num)
        root.addView(label)

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", (16 * d).toInt())
            y = prefs.getInt("y", (300 * d).toInt())
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        var moved = false; var downT = 0L
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; downT = e.eventTime; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt()
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    } else if (e.eventTime - downT > 700) {
                        setCount(0)
                    } else {
                        setCount(count + 1)
                        buzz(count % target == 0)
                    }
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
        bubble = root
    }

    private fun setCount(n: Int) {
        count = n
        num.text = n.toString()
        prefs.edit().putInt("count", n).apply()
    }

    private fun buzz(long: Boolean) {
        val v = getSystemService(Vibrator::class.java) ?: return
        val fx = if (long) VibrationEffect.createWaveform(longArrayOf(0, 60, 40, 120), -1)
        else VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE)
        v.vibrate(fx)
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }
}
